
public interface MyInterface extends VersionedProtocol{
	long versionID = 1L;
	int add(int number1, int number2);

}
