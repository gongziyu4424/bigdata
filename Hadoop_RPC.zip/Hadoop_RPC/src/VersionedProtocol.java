import java.io.IOException;


public interface VersionedProtocol {

	long getProtocolVersion(String protocol, long clientVersion)
			throws IOException;

}
