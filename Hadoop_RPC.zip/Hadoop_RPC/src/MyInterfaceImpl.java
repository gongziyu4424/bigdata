import java.io.IOException;


public class MyInterfaceImpl implements MyInterface{
	@Override
	public int add(int number1, int number2){
		System.out.println("number1 = " + number1 + " number2 = " + number2);
		return number1 + number2;
	}
	
	@Override
	public long getProtocolVersion(String protocol, long clientVersion) throws IOException{
		return MyInterface.versionID;
	}
}
