import java.io.IOException;


public class add_server {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			MyInterface proxy = RPC.getProxy(MyInterface.class, 1L, new InterSocketAdd());
			int res = proxy.add(1,2);
			System.out.print(res);
		} catch (IOException e){
			e.printStackTrace();
		}

	}

}
